function display_c(){
  var refresh = 1000; // Refresh rate in milli seconds
  mytime = setTimeout('display_ct()', refresh)
}

function display_ct() {
  var x = new Date()
  document.getElementById('ct').innerHTML = x.toLocaleString();
  display_c();
}

time1 = new Date(0, 0, 0, 7, 45, 0)
time2 = new Date(0, 0, 0, 8, 12, 0)
time3 = new Date(0, 0, 0, 8, 15, 0)
time4 = new Date(0, 0, 0, 8, 45, 0)
time5 = new Date(0, 0, 0, 8, 47, 0)
time6 = new Date(0, 0, 0, 9, 32, 0)
time7 = new Date(0, 0, 0, 9, 47, 0)
time8 = new Date(0, 0, 0, 9, 49, 0)
time9 = new Date(0, 0, 0, 10, 34, 0)
time10 = new Date(0, 0, 0, 10, 39, 0)
time11 = new Date(0, 0, 0, 11, 5, 0)
time12 = new Date(0, 0, 0, 11, 8, 0)
time13 = new Date(0, 0, 0, 11, 50, 0)
time14 = new Date(0, 0, 0, 11, 53, 0)
time15 = new Date(0, 0, 0, 12, 23, 0)
time16 = new Date(0, 0, 0, 12, 38, 0)
time17 = new Date(0, 0, 0, 12, 41, 0)
time18 = new Date(0, 0, 0, 12, 51, 0)
time19 = new Date(0, 0, 0, 12, 56, 0)
time20 = new Date(0, 0, 0, 13, 21, 0)
time21 = new Date(0, 0, 0, 13, 26, 0)
time22 = new Date(0, 0, 0, 13, 44, 50)
time23 = new Date(0, 0, 0, 14, 13, 0)
time24 = new Date(0, 0, 0, 14, 15, 0)
time25 = new Date(0, 0, 0, 15, 0, 0)

var times = [time1, time2, time3, time4, time5, time6, time7,
time8, time9, time10, time11, time12, time13, time14, time15, time16,
time17, time18 time19, time20, time21, time22, time23, time24, time25]
